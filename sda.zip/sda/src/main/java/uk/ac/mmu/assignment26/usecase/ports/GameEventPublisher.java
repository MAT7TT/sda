package uk.ac.mmu.assignment26.usecase.ports;

public interface GameEventPublisher {
    void publish(Object event);
}